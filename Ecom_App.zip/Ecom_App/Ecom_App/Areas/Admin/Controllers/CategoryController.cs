﻿using Ecom_App.DataAccess.Repository.IRepository;
using Microsoft.AspNetCore.Mvc;

namespace Ecom_App.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class CategoryController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        public CategoryController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public IActionResult Index()
        {
            return View();
        }
        #region APIs
        [HttpGet]
        public IActionResult GetAll()
        {
            var objCategoryList = _unitOfWork.Category.GetAll();
            return Json(new { data = objCategoryList });
        }
        #endregion
    }
}
