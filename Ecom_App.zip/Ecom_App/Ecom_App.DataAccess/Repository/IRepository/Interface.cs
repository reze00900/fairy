﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Ecom_App.DataAccess.Repository.IRepository
{
    // Generic repository interface for CRUD + queries
    public interface IRepository<T> where T : class
    {
        // Create
        void Add(T entity);

        // Update
        void Update(T entity);

        // Delete
        void Remove(T entity);
        void Remove(int id);
        void RemoveRange(IEnumerable<T> entities);

        // Read
        T Get(int id);

        IEnumerable<T> GetAll(
            Expression<Func<T, bool>> filter = null,
            Func<IQueryable<T>, IOrderedQueryable<T>> orderBy = null,
            string includeProperties = null
        );

        T FirstOrDefault(
            Expression<Func<T, bool>> filter = null,
            string includeProperties = null
        );
    }
}
